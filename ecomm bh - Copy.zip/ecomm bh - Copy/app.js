const express              = require("express"),
 app                       = express(),
 mongoose                  = require("mongoose"),
 bodyParser                = require("body-parser"),
 cookieParser               = require("cookie-parser"),
 shop                      = require("./routes/shop"),
 admin                     = require("./routes/admin"),
 authRoutes                = require("./routes/auth"),
 methodOverride            = require("method-override"),
 User                      = require("./models/user"),
 Product                   = require("./models/product");

 
mongoose.connect("mongodb://localhost/ecomm",{ useNewUrlParser: true });
app.use(express.static("public"));
app.use(methodOverride("_method"));
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended: true}));

// const user = new User({
//     name:"shabbir",
//     email:"educationispower@gmail.com",
//     cart:{
//         items:[]
//     }
// });
// user.save();



app.use((req,res,next)=>{
    User.findById('5db80eab76f1cf0c08bad646')
    .then(user => {
        req.user = user;
        next();
    })
    .catch(err=> {
        console.log(err);
    })
})

app.use("/admin",admin);
app.use(shop);
app.use(authRoutes);
app.use(cookieParser())


app.use("/",(req,res)=>{
    res.send("Page Not Found")
})

app.listen("3000",()=>{
    console.log("server started");
})