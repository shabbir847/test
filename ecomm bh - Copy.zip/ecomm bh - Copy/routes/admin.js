const express  = require("express"),
      router   = express.Router(),
      mongoose = require("mongoose"),
      Product  = require("../models/product");

router.get("/add-product",(req,res)=>{
    res.render("admin/add_pro_form",{
         path:"/admin/add-product",
         title:"Add-Product",
         isAuthenticated : req.isLoggedIn
    });
});
router.post("/add-product",(req,res)=>{
    const product = {
        title       : req.body.title,
        price       : req.body.price,
        description : req.body.description,
        imgUrl      : req.body.imgUrl,
        userId      : req.user,
        // username    : req.user.name
    }
    Product.create(product,(err,pro)=>{
        if(err){
            console.log(err)
        }else{
            // console.log(req.user);
            res.redirect("/admin/products");
        }
    })
});
router.get("/products",(req,res)=>{
    Product.find({},(err,product)=>{
        if(err){
            console.log(err)
        }else{
            res.render("admin/dis_admin_pro",{
                product:product,
                title:"Admin Product",
                path:"/admin/products",
                isAuthenticated : req.isLoggedIn
            });
        }
    })
});

router.get("/:id/edit",(req,res)=>{
    Product.findById(req.params.id,(err,product)=>{
        if(err){
            console.log(err)
        }else{
            res.render("admin/edit-product",{
                product:product,
                isAuthenticated : req.isLoggedIn
            })
        }
    })
})

router.put("/:id",(req,res)=>{
    Product.findByIdAndUpdate(req.params.id,req.body.product,(err,product)=>{
        if(err){
            console.log(err)
        }else{
            res.redirect("/admin/products");
        }
    })
})

router.delete("/:id",(req,res)=>{
    Product.findByIdAndRemove(req.params.id,(err,pro)=>{
        if(err){
            console.log(err);
        }else{
            res.redirect("/admin/products");
        }
    })
})

module.exports = router;