const express  = require("express"),
      router   = express.Router(),
      mongoose = require("mongoose");

router.get("/login",(req,res,next)=> {
    const isLoggedIn = req
    .get('Cookie')
    .split('=')[1]
    console.log(isLoggedIn)
    res.render("auth/login",{
        path:"/login",
        title:"Login Form",
        isAuthenticated : isLoggedIn
    })
});

router.post("/login",(req,res,next)=> {
    res.setHeader('Set-Cookie','loggedIn=true');
    res.redirect("/");
})

module.exports = router;