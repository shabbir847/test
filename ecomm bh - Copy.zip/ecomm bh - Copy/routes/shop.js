const express = require("express"),
    router = express.Router(),
    mongoose = require("mongoose"),
    User = require("../models/user");
    Product = require("../models/product");
    Order   = require("../models/order");
    
router.get("/", (req, res) => {
    Product.find({}, (err, product) => {
        if (err) {
            console.log(err)
        } else {
            res.render("shop/index", {
                product: product,
                title:"Products",
                path: "/",
                isAuthenticated : req.isLoggedIn
            });
        }
    })
})

router.get("/products", (req, res) => {
    Product.find({}, (err, product) => {
        if (err) {
            console.log(err)
        } else {
            res.render("shop/dis_user_pro", {
                product: product,
                title:"Products",
                path: "/products",
                isAuthenticated : req.isLoggedIn
            });
        }
    })
})

router.get("/products/:id",(req,res)=>{
    Product.findById(req.params.id,(err,product)=>{
        if(err){
            console.log(err)
        }else{
            res.render("shop/dis_user_sps_pro",{
                product:product,
                title:"Product Detail",
                path:"/products",
                isAuthenticated : req.isLoggedIn
            })
        }
    })
})

router.get("/cart",(req,res,next)=>{
    req.user
    .populate('cart.items.productId')
    .execPopulate()
    .then(user => {
        const product = user.cart.items;
        res.render("shop/cart",{
            path:"/cart",
            title:"Your Cart",
            product :product,
            isAuthenticated : req.isLoggedIn
        })
    })
    .catch(err => console.log(err));
})

router.post("/cart",(req,res,next)=>{
    const prodId = req.body.productId;
    Product.findById(prodId)
    .then(product => {
        return req.user.addToCart(product);
    })
    .then(result => {
        console.log(result);
        res.redirect("/admin/products");
    });
});

router.post("/cart-delete-item",(req,res,next)=> {
    const prodId = req.body.productId;
    req.user.removeFromCart(prodId)
    .then(result => {
        res.redirect("/cart");
    })
    .catch(err => {
        console.log(err)
    })
})

router.post('/create-order',(req, res, next) => {
    req.user
      .populate('cart.items.productId')
      .execPopulate()
      .then(user => {
        const products = user.cart.items.map(i => {
          return { quantity: i.quantity, product: { ...i.productId._doc } };
        });
        const order = new Order({
          user: {
            name: req.user.name,
            userId: req.user
          },
          products: products
        });
        return order.save();
      })
      .then(result => {
        return req.user.clearCart();
      })
      .then(() => {
        res.redirect('/orders');
      })
      .catch(err => console.log(err));
  });


router.get('/orders',(req,res,next)=> {
    Order.find({'user.userId' : req.user._id})
    .then(orders => {
        res.render("shop/orders",{
            path:'/orders',
            title:"Your Orders",
            orders : orders,
            isAuthenticated : req.isLoggedIn
        });
    })
    .catch(err => console.log(err))
})


module.exports = router;