var methodOverride = require("method-override"), 
Blog               = require("./models/blog"),
mainroute          = require("./routes/main"), 
bodyParser         = require("body-parser"),  
mongoose           = require("mongoose"),
express            = require("express"),
app                = express();

app.use(express.static("public"));
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(methodOverride("_method"))
mongoose.connect('mongodb://localhost:27017/blog_app', { useNewUrlParser: true }); 

app.use(mainroute);

app.use("/",(req,res,next)=> {
    res.send("Page Not Found");
});

app.listen("3000",(req,res,next)=>{
    console.log("server started");
});