const express  = require("express"),
      router   = express.Router(),
      Blog     = require("../models/blog");

    router.get("/",(req,res,next)=>{
        res.redirect("/blogs")
    })

//index route
 router.get("/blogs",(req,res,next)=>{
    Blog.find({},(err,blog2)=>{
        if(err){
            console.log(err);
        }else{
            res.render("index",{blog2:blog2})
        }
    });
});

// new route
 router.get("/blogs/new",(req,res,next)=>{
    res.render("new");
})

// create route
 router.post("/blogs",(req,res,next)=>{
    Blog.create(req.body.Blog,(err,newlycreated)=>{
        if(err){
            console.log(err);
        }else{
            res.redirect("/blogs");
        }
        });
})
// show route
 router.get("/blogs/:id",function(req,res){
    Blog.findById(req.params.id,(err,blog3)=>{
        if(err){console.log(err)}
        else{
            res.render("show",{blog3:blog3})
        }
    })
})
// edit route
 router.get("/blogs/:id/edit",(req,res,next)=>{
    Blog.findById(req.params.id,(err,found)=>{
        if(err){
            console.log(err)
        }else{
            res.render("edit",{blog:found})
        }
    })
})
// update route
 router.put("/blogs/:id",(req,res,next)=>{
    Blog.findByIdAndUpdate(req.params.id,req.body.Blog,(err,allwell)=>{
        if(err){
            console.log(err)
        }else{
            res.redirect("/blogs");
        }
    })
})
// delete route
 router.delete("/blogs/:id",(req,res,next)=>{
    Blog.findByIdAndRemove(req.params.id,function(err){
        if(err){
            console.log(err)
        }else{
            res.redirect("/blogs");
        }
    })
})

module.exports = router;